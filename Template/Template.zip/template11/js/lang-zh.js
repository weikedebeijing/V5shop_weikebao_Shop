// JavaScript Document
var v5Lang = {
	txtName:"please select name"
}